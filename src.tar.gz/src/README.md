# Keya-AI
An offline voice controlled home automation system and facial recognition 
