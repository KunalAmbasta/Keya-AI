from distutils.core import setup

setup(
    # Application name:
    name="superkeya",

    # Version number (initial):
    version="0.1.0",

    # Application author details:
    author="Kunal Ambasta",
    author_email="developers21.sas@gmail.com",

    # Packages
    packages=["superkeya"],
    
    data_files = [
        ('share/applications/', ['superkeya.desktop'])
    ],

    # Include additional files into the package
    include_package_data=True,

    package_data={
   'superkeya.keyaData': ['*'],     # All files from keyaData folder
   'superkeya.superkeya.keyaData': ['*']     # All files from keyaData folder
   },

    # Details
    url="http://www.mulgyan.com",

    #
    license="LICENSE.txt",
    description="KEYA - Artificially Intelligent Personal Assistant",

    long_description=open("README.txt").read(),

    # Dependent packages (distributions)
    install_requires=[
        "opencv-python","numpy","RPi.GPIO","pyaudio","python-aiml","pyowm","wikipedia","duckduckgo", "SpeechRecognition","pocketsphinx"
    ],
)
