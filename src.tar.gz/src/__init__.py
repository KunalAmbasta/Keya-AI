import superkeya
superkeya.main()
